from Ld_Models import Ld_st, Ld_turb, Ld_tab

def Ld_calc(LCOR, Qgas, d_mm, Mu, Ro, Lk, Ld_tab_value):
    """
    Универсальная оболочка расчёта гидравлической длины.

    Параметры:
    - LCOR (str): метод расчёта ('ламинарный', 'турбулентный', 'таблица')
    - Qgas (float): расход газа, м³/сут
    - d_mm (float): диаметр трубы, мм
    - Mu (float): вязкость газа, Па·с
    - Ro (float): относительная плотность газа
    - Lk (float): длина участка трубы, м
    - Ld_tab_value (float): табличное значение длины, м

    Возвращает:
    - Ld (float): расчётная гидравлическая длина
    """
    method = LCOR.strip().lower()

    if method == 'турбулентный':
        return Ld_turb(d_mm, Lk)
    elif method == 'ламинарный':
        return Ld_st(Qgas, d_mm, Mu, Ro, Lk)
    elif method == 'таблица':
        return Ld_tab(Ld_tab_value)
    else:
        raise ValueError(f"Неизвестный метод расчёта гидравлической длины: '{LCOR}'")
