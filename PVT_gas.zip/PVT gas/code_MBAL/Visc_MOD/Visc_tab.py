from scipy.interpolate import CubicSpline

def Visc_tab(P_MPA, pressure_data, visc_data):
    """
    Интерполяция/экстраполяция динамической вязкости газа по табличным данным.

    Параметры:
    - P_MPA (float): давление, МПа
    - pressure_data (list): давления, МПа
    - visc_data (list): вязкость, мкПа·с

    Возвращает:
    - μ (float): вязкость газа, мкПа·с
    """
    if len(pressure_data) < 2:
        raise ValueError("Недостаточно данных для интерполяции")

    spline = CubicSpline(pressure_data, visc_data, extrapolate=True)
    return float(spline(P_MPA))
