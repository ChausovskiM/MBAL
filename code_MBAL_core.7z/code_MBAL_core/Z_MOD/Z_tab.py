import math
from scipy.interpolate import CubicSpline

def Z_tab(P_MPA, pressure_data, z_data):
    """
    Интерполяция/экстраполяция коэффициента Z по кубическому сплайну.

    Параметры:
    - P_MPA (float): давление, МПа
    - pressure_data (list): список давлений (МПа)
    - z_data (list): соответствующие значения коэффициента Z

    Возвращает:
    - Z (float): интерполированное или экстраполированное значение Z
    """
    if len(pressure_data) < 2:
        raise ValueError("Недостаточно данных для интерполяции")

    spline = CubicSpline(pressure_data, z_data, extrapolate=True)
    return float(spline(P_MPA))
