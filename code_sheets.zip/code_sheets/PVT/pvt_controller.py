import json
import math
import matplotlib.pyplot as plt
from code_MBAL_core.Z_MOD.Z_GUR import Z_GUR
from code_MBAL_core.Z_MOD.Z_PR import Z_PR
from code_MBAL_core.Z_MOD.Z_BB import Z_BB
from code_MBAL_core.Visc_MOD.Visc_JST import Visc_JST
from code_MBAL_core.Visc_MOD.Visc_Lee_Gonzalez import Visc_Lee_Gonzalez






# === Загрузка данных ===
def load_input(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_components(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

# === Главный расчётный блок ===
def calc_mixture_params(gas_components):
    """
    Вычисляет средние параметры смеси: молекулярный вес, критическую температуру и давление.

    Ожидается, что mol_fraction_pct передаётся в процентах (%).
    """
    mw = sum(comp["mol_fraction_pct"] / 100 * comp["Mw"] for comp in gas_components)
    tc = sum(comp["mol_fraction_pct"] / 100 * comp["Tc"] for comp in gas_components)
    pc = sum(comp["mol_fraction_pct"] / 100 * comp["Pc"] for comp in gas_components)
    return mw, tc, pc


def prepare_inputs_from_components(gas_components):
    """
    Преобразует список компонентов газа в набор входных параметров
    для функции Z_PR: XiRange, Pc, Tc, Vc, w

    Параметры:
    - gas_components (list[dict]): список словарей с параметрами компонентов

    Возвращает:
    - XiRange, Pc, Tc, Vc, w (все списки float)
    """
    XiRange = [comp["mol_fraction_pct"] for comp in gas_components]
    Pc = [comp["Pc"] for comp in gas_components]       # МПа
    Tc = [comp["Tc"] for comp in gas_components]       # K
    Vc = [comp["Vc"] for comp in gas_components]       # см³/моль
    w  = [comp["w"] for comp in gas_components]        # безразмерный

    return XiRange, Pc, Tc, Vc, w



# === Расчёт значений для таблицы (строки 4,5,6,8,10,12,13,15,17,18,19) ===
def main():
    props = load_input("input_properties.json")
    gas_components = load_components("gas_components.json")
    

    Mw_mix, Tc_mix, Pc_mix = calc_mixture_params(gas_components)
    XiRange, Pc, Tc, Vc, w = prepare_inputs_from_components(gas_components)
    T_C_plast = props["T_plast_C"]
    P_Mpa = props["P_plast_MPA"]
    Z_method = props["Z_method"]
    density_method = props["density_method"]
    viscosity_method = props["viscosity_method"]
    Z_fact = props["Z_fact"]
    

    # Захардкоженный массив давлений (МПа)
    P_list = [0.1, 5.1, 10.1, 15.1, 20.1, 25.1, 30.1, 35.1, 40.1, 45.1, 50.1, 55.1, 60.1, 65.1, 70.1]

    # Расчёт таблицы расчётных параметров (строки 4,5,6,8,10,12,13,15,17,18,19)
    P_plast = props["P_plast_MPA"]
    T_plast = props["T_plast_C"]
    metod = Z_method.strip().lower()
    m = Mw_mix / 28.96
    Pkri = P_plast /  Pc_mix
    Tkri = T_plast / Tc_mix

    if metod == 'beggs и brill':
        Z_calc = Z_BB(P_Mpa, T_C_plast, Pc_mix, Tc_mix)
    elif metod == 'латонов-гуревич':
        Z_calc = Z_GUR(P_Mpa, T_C_plast, Pc_mix, Tc_mix)
    elif metod == 'пенг-робинсон':
        Z_calc = Z_PR(P_Mpa, T_C_plast, XiRange, Pc, Tc, Vc, w)
    else:
        raise ValueError(f"Неизвестный метод расчёта Z: '{metod}'")
    rho0 = Mw_mix / 24.04  # нормальная плотность, кг/м³
    rho = rho0 * P_Mpa * 293.15 / (101325 * T_C_plast * Z_calc)
    
    viscosity_method = viscosity_method.strip().lower()
    #поправить ввод на функцию
    if viscosity_method == 'jossi stiel thodos':
        mu =  Visc_JST(P_Mpa, T_C_plast, Z_calc, rho, Mw_mix) / 1000  # перевод из мкПа·с в Па·с
    elif viscosity_method == 'lee-gonzalez':
        mu = Visc_Lee_Gonzalez(P_Mpa, T_C_plast, Z_calc) / 1000
    else:
        raise ValueError(f"Неизвестный метод расчёта вязкости: '{viscosity_method}'")
    
    
    
    
    
    Bg = 0.0357 * Z_calc / P_Mpa * (T_C_plast + 273.15)

    Ppr = P_plast / Pkri
    Tpr = (T_plast + 273.15) / Tkri
    rho_std = m / 0.02896
    visc_std = 0.011
    deviation_Z = 100 * (Z_fact - Z_calc) / Z_fact
    deviation_mu = 100 * (props["viscosity_fact_cP"] - mu) / props["viscosity_fact_cP"]

    summary = {
        "Ppr": round(Ppr, 4),
        "Tpr": round(Tpr, 4),
        "m": round(m, 4),
        "Z_calc": round(Z_calc, 5),
        "Z_deviation": round(deviation_Z, 2),
        "rho": round(rho, 3),
        "rho_std": round(rho_std, 3),
        "mu": round(mu, 5),
        "mu_std": round(visc_std, 3),
        "mu_deviation": round(deviation_mu, 2),
        "Bg": round(Bg, 5)
    }

    with open("output_pvt_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)


    results = []
    for P in P_list:
        Zpr = Z_PR(P, T_C_plast, XiRange, Pc, Tc, Vc, w)
        Zbb = Z_BB(P, T_C_plast, Pc_mix, Tc_mix)
        Zgur = Z_GUR(P, T_C_plast, Pc_mix, Tc_mix)

        rho0 = Mw_mix / 24.04  # нормальная плотность, кг/м³
        rho = rho0 * P * 293.15 / (101325 * T_C_plast * Zbb)

    

        visc_lg = Visc_Lee_Gonzalez(T_C_plast,  rho, m)
        visc_jst = Visc_JST(P, T_C_plast, Zbb)
        Bg = 0.0357 * (Zbb / P) * (T_C_plast + 273.15)

        results.append({
            "P_MPA": round(P, 3),
            "ZPr": round(Zpr, 5),
            "ZBB": round(Zbb, 5),
            "ZGUR": round(Zgur, 5),
            "Density": round(rho, 5),
            "LG": round(visc_lg, 6),
            "JST": round(visc_jst, 6),
            "Bg": round(Bg, 5)
        })

    with open("output_pvt_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    import matplotlib.pyplot as plt

    # Данные
    P = [row["P_MPA"] for row in results]

    Z_bb = [row["ZBB"] for row in results]
    Z_pr = [row["ZPr"] for row in results]
    Z_gur = [row["ZGUR"] for row in results]

    rho = [row["Density"] for row in results]
    mu_lg = [row["LG"] for row in results]
    mu_jst = [row["JST"] for row in results]
    Bg = [row["Bg"] for row in results]

    # === 2 строки × 2 столбца ===
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))

    # --- Z-фактор ---
    axs[0, 0].plot(P, Z_bb, label="Z_BB", marker='o')
    axs[0, 0].plot(P, Z_pr, label="Z_PR", marker='x')
    axs[0, 0].plot(P, Z_gur, label="Z_GUR", marker='s')
    axs[0, 0].set_title("Z-фактор по давлению")
    axs[0, 0].set_ylabel("Z")
    axs[0, 0].legend()
    axs[0, 0].grid(True)

    # --- Плотность ---
    axs[0, 1].plot(P, rho, marker='o', color='tab:blue')
    axs[0, 1].set_title("Плотность газа по давлению")
    axs[0, 1].set_ylabel("ρ, кг/м³")
    axs[0, 1].grid(True)

    # --- Вязкость ---
    axs[1, 0].plot(P, mu_lg, label="Lee-Gonzalez", marker='o')
    axs[1, 0].plot(P, mu_jst, label="Jossi-Stiel-Thodos", marker='x')
    axs[1, 0].set_title("Вязкость газа по давлению")
    axs[1, 0].set_xlabel("Давление, МПа")
    axs[1, 0].set_ylabel("μ, сП")
    axs[1, 0].legend()
    axs[1, 0].grid(True)

    # --- Bg ---
    axs[1, 1].plot(P, Bg, marker='o', color='tab:green')
    axs[1, 1].set_title("Объёмный коэффициент Bg")
    axs[1, 1].set_xlabel("Давление, МПа")
    axs[1, 1].set_ylabel("Bg, м³/м³")
    axs[1, 1].grid(True)

    plt.tight_layout()
    plt.show()



if __name__ == "__main__":
    main()
